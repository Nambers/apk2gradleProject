pluginManagement {
    repositories {
        gradlePluginPortal()
        google()
    }
}

rootProject.name = "QQAndroid-FF"

include(":app")
